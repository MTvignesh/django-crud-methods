from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from.serializers import productserializers
from .models import product

#@api_view(['GET'])
# def appi(request):
  #  api_urls={
   #     'list':'/product-list/',
    #    'detail_view':'/product-detail/<int:id>/',
     #   'create':'/product-create/',
     #   'update':'/product-update/<int:id>/',
      #  'delete':'/product-delete/<int:id>/',
            
  #  }
 #   return Response(api_urls);

@api_view(['GET'])
def showall(request):
    products =product.objects.all()
    serial =productserializers(products,many=True)
    return Response(serial.data)
    
@api_view(['GET'])
def viewproduct(request,pk):
    products =product.objects.get(id=pk)
    serial =productserializers(products,many=False)
    return Response(serial.data)
    
@api_view(['POST'])
def create(request):

    serial =productserializers(data=request.data)
    
    if serial.is_valid():
        serial.save()
        
    return Response(serial.data)

@api_view(['POST'])
def update(request,pk):
    products =product.objects.get(id=pk)
    serial =productserializers(instance=products,data=request.data)
    if serial.is_valid():
        serial.save()
    return Response(serial.data)
    
@api_view(['DELETE'])
def delete(request,pk):
    products =product.objects.get(id=pk)
    products.delete()
    return Response('DELETED')