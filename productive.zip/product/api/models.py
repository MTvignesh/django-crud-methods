from django.db import models

# Create your models here.
class product(models.Model):
    name:models.CharField(max_length=100,null=False,blank=False)
    price:models.DecimalField(max_digits=5,decimal_places=2)
    catagory:models.DecimalField(max_digits=100,null=False,blank=False)
    description:models.TextField()
    stars = models.IntegerField()
    
    def __str__(self):
        return self.name
