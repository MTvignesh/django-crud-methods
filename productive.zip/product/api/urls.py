from django.urls import path
from .import views

urlpatterns=[
    #path('',views.appi,name='appi'),
    path('product-list/',views.showall,name='product-list'),
    path('product-detail/<int:pk>/',views.viewproduct,name='product-detail'),
    path('product-create/',views.create,name='product-create/'),
    path('product-update/<int:id>/',views.update,name='product-update'),
    path('product-delete/<int:id>/',views.delete,name='product-delete'),
]
